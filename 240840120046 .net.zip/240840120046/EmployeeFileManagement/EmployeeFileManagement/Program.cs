﻿using System;
using System.Collections.Generic;
using System.IO;

namespace EmployeeFileManagement
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public decimal Salary { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> employees = new List<Employee>();
            string filePath = "EmployeeData.txt";

            Console.WriteLine("Enter the number of employees:");
            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                Console.WriteLine($"\nEnter details for employee {i + 1}:");
                Console.Write("Employee ID: ");
                int employeeId = int.Parse(Console.ReadLine());

                Console.Write("Name: ");
                string name = Console.ReadLine();

                Console.Write("Salary: ");
                decimal salary = decimal.Parse(Console.ReadLine());

                employees.Add(new Employee { EmployeeId = employeeId, Name = name, Salary = salary });
            }

            SaveToTextFile(employees, filePath);

            List<Employee> fileData = ReadFromTextFile(filePath);
            Console.WriteLine("\nData from text file:");
            foreach (var employee in fileData)
            {
                Console.WriteLine($"Employee ID: {employee.EmployeeId}, Name: {employee.Name}, Salary: {employee.Salary}");
            }
        }

        static void SaveToTextFile(List<Employee> employees, string filePath)
        {
            FileStream fs = new FileStream(filePath, FileMode.Create);
            StreamWriter writer = new StreamWriter(fs);

            try
            {
                foreach (var employee in employees)
                {
                    writer.WriteLine($"{employee.EmployeeId},{employee.Name},{employee.Salary}");
                }
            }
            finally
            {
                writer.Close();
                fs.Close();
            }

            Console.WriteLine($"\nData saved to text file: {filePath}");
        }

        static List<Employee> ReadFromTextFile(string filePath)
        {
            List<Employee> employees = new List<Employee>();

            if (File.Exists(filePath))
            {
                FileStream fs = new FileStream(filePath, FileMode.Open);
                StreamReader reader = new StreamReader(fs);

                try
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        var parts = line.Split(',');

                        var employee = new Employee
                        {
                            EmployeeId = int.Parse(parts[0]),
                            Name = parts[1],
                            Salary = decimal.Parse(parts[2])
                        };

                        employees.Add(employee);
                    }
                }
                finally
                {
                    reader.Close();
                    fs.Close();
                }
            }
            else
            {
                Console.WriteLine("File not found!");
            }

            return employees;
        }
    }
}
